import { NoteOnEvent, NoteOffEvent, Track, File } from "@perry-rylance/midi";

export default new File().tracks([
    new Track().events(
        [0, 2, 4, 5, 7, 9, 11, 12].flatMap(semitone => [
            new NoteOnEvent().key(60 + semitone),
            new NoteOffEvent().delta(480).key(60 + semitone)
        ])
    )
]);
